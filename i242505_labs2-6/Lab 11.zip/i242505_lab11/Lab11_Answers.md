# FAST NUCES - DAV Lab 11: Complete Answers

Dataset: `Tweets.csv` (14,640 tweets, February 2015). Lexicon-based tool: TextBlob.

## Part A - 1. Why a naive tokenizer fails

The raw tweets contain @handles in 14,640 tweets, hashtags in 2,375, links in 1,173, emojis in 427, and stretched words in 107. A naive `\b\w+\b` tokenizer turns `@VirginAmerica` into `virginamerica`, splits web links into junk tokens, drops emoji, and leaves `heyyyy` unchanged. My cleaner removes handles and URLs, keeps the words inside hashtags, shortens stretched spelling, and leaves original tweets untouched for sentiment scoring. The airline identity is already in the `airline` column. Emojis are lost from word-frequency charts, which is a limitation. This file also contains replacement artifacts such as `Cancelled Flightled` (763 tweets with similarly altered variants); the code corrects recognizable versions before phrase analysis.

## Part A - 2. Stop words and negation

Removing words like **not**, **no**, or **nor** can reverse a tweet's meaning: `not good` scores -0.35 in TextBlob, but `good` scores +0.70. Removing the negation terms alone changed model classifications on **339 tweets**. The final stop-word list therefore keeps `not`, `no`, `nor`, `never`, `none`, and related negatives. This is important for both n-grams and sentiment.

## Part A - 3. Stemming versus lemmatization

Porter stemming reduces `services` to `servic` and `customer` to `custom`, which are harder for a manager to read. The lightweight rule-based lemmatizer keeps `service` and `customer`. After stop-word removal, the vocabulary has **10,999** words; lightweight lemmatization gives **10,132**, while stemming gives **8,403**. I choose the readable lemma-like method for these charts. **Limit:** it is a simple rule-based approximation, not a full dictionary/POS-tagging lemmatizer.

## Part A - 4. Cleaning costs

Vocabulary shrinks from **15,089** raw types to **10,132**. Mean tokens per tweet fall from **18.35** to **7.99** and **48 tweets** become empty (0.33%). Noise removal helps the charts, but stop-word removal discards context; retain original text for the sentiment model and any manual review.

## Part B - 5. Raw-frequency noise

In the raw top words, `united` appears **4,164** times, `usairways` **3,053** and `americanair` **2,964**. These mostly identify whom the user addressed, rather than what happened. Removing handle tokens, airline names and common filler reveals substantive terms such as `flight`, `delay`, `cancel`, `service`, and `help`. All tweets contain an @handle, indicating a collection focused on tweets addressed to airline accounts, not random passenger feedback.

Related chart(s): `charts/01_raw_top_words.png`, `charts/02_clean_top_words.png`

## Part B - 6. Words separating positive and negative tweets

I computed TF-IDF for each cleaned tweet and compared mean TF-IDF between human-positive and human-negative tweets. **Positive-distinctive:** `thank`, `great`, `love`. **Negative-distinctive:** `not`, `hour`, `delay`, `cancel`, `hold`. Raw frequency is misleading because words like `flight` are common in both groups and because the negative group contains far more tweets. A difference in mean TF-IDF is a better measure of distinction, though not a causal explanation.

Related chart(s): `charts/03_distinctive_tfidf.png`, `charts/13_butterfly_words.png`

## Part B - 7. Operational phrases and negation

Negative tweets include **customer service** (458 cleaned bigrams), **hold hour** (152), and **flight delay** (157). These phrases point to service/contact delays and flight disruption, more clearly than a single word like `hour`. The pair **not happy** occurs in 23 negative raw tweets; `happy` alone scores +0.80, whereas `not happy` scores -0.40. Keeping negation reveals the change in meaning. Some bigrams are grammatical fragments because removing stop words can join originally nonadjacent words.

Related chart(s): `charts/04_negative_ngrams.png`

## Part B - 8. Word cloud or bar chart?

I would show the **bar chart**. It gives precise, comparable counts and is easy to rank. A word cloud communicates rough emphasis but hides the actual values and can overstate differences through font size and layout. Both visuals here use the same negative-word counts; the cloud is supplementary.

Related chart(s): `charts/05_negative_bar_vs_cloud.png`

## Part C - 9. TextBlob sentiment versus human labels

Every tweet was scored with TextBlob polarity, then labeled positive above +0.10, negative below -0.10, and otherwise neutral. Accuracy is **43.4%** (macro F1 **0.44**). The negative class is hardest: recall only **28.6%**, versus 64.8% for neutral and 72.7% for positive. It misses **6,556** human-negative tweets. Overall accuracy hides these false negatives; predicting `negative` for every tweet would already get **62.7%** accuracy on this imbalanced sample.

Related chart(s): `charts/06_sentiment_confusion_matrix.png`

## Part C - 10. Why the tool disagrees

There are **8,291** mismatches. Among the **6,556** missed negative tweets, approximate keyword-based tags find **negation** 2,914, **airline operations** 865, **mixed/contrast** 348, and **possible sarcasm** 127; 2,302 are unclear. Negation is the largest *identified* category. These tags are guesses, not verified explanations, particularly for sarcasm. Fixes: preserve negation, add domain terms (`cancelled`, `stranded`, `lost baggage`), train with airline-labeled examples, and send uncertain cases to people.

Related chart(s): `charts/07_error_cause_tags.png`

## Part C - 11. Three deliberately difficult tweets

The examples below were written for this lab and are **intended to be negative**. TextBlob incorrectly rates two as positive and one as neutral. The first and third use praise sarcastically; the second contains strong operational complaints without words in the general sentiment lexicon.

## Part C - 12. Human-label confidence

Keeping only human-labeled tweets with `airline_sentiment_confidence >= 0.90` leaves **10,458** of 14,640 tweets. Model accuracy changes from **43.4%** to **44.1%**, with macro F1 from **0.440** to **0.441**. The small improvement means high-confidence labels do not solve the model's errors. Confidence is metadata about the labeling process, not proof that every label is correct.

## Part D - 13. Customer service or operations?

Complaint reasons are already labeled in the file. Of **American** negative tweets, **43.6%** are service-related and **39.6%** operations-related. At **Delta**, service is **27.1%** and operations **48.8%**; **United** has **47.9%** operations-related. This supports different *mixes* of issues, not proof of root cause or absolute service quality.

Related chart(s): `charts/08_airline_complaint_heatmap.png`, `charts/09_airline_reason_stacked.png`

## Part D - 14. Counts versus shares

**United** has the most negative tweets (**2,633**), but **US Airways** has the highest negative *rate* (**77.7%**, compared with United's **68.9%**). Count partly reflects tweet volume; a percent gives the fairer cross-airline comparison. Report both: rates for benchmarking and counts for deciding support staffing.

Related chart(s): `charts/10_airline_negative_count_vs_rate.png`, `charts/14_stacked_airline_sentiment.png`

## Part D - 15. Changes over time

On **22 February 2015**, the file has **3,079** tweets, of which **2,266** are negative (**73.6%**); this is a high-volume/high-negative day. The first day has only four tweets and is excluded from the negative-rate trend. A spike exists, but the tweets alone cannot establish whether weather, cancellations, account selection, time zones, or other events caused it.

Related chart(s): `charts/11_sentiment_over_time.png`, `charts/12_daily_negative_rate.png`

## Part D - 16. Which negative tweets get answered first?

Practical demonstration rule: **P1** = negative, about cancellation/delay/lost luggage, and either urgent wording or at least 2 retweets; **P2** = other negative disruption or at least 2 retweets; **P3** = other negatives. It flags **790** P1, **2,501** P2, **5,887** P3 in these *historical* tweets. In real deployment, do not rely on a low-recall TextBlob label alone: verify disruption, active flight details and customer safety with humans.

## Part E - 17. Biases and least trustworthy finding

This is not a random sample: (1) unhappy people may post more often, (2) collection around @airline handles favors public complaints/engagement, and (3) the sample spans only nine dates. There are also **213** duplicate text records and missing geolocation. I trust a proposed **cause of the daily spike** least: tweet counts show timing, not why it happened. Current airline rankings from 2015 are also not trustworthy.

## Part E - 18. What would change with modern data?

The rankings, complaint rates, social-platform behavior, airline mix, customer expectations, and digital-service issues could all change substantially by **2026**. Broader themes such as late flights and customer service may remain, but their frequencies and phrasing may shift. This 2015 file cannot measure present-day conditions; recollect current, representative data before acting on today's rankings.

## Part E - 19. Replace the manual reading team?

**No.** A model with **43.4%** accuracy and only **28.6%** recall for negative tweets is unsafe for unattended complaint handling. Use it to **sort and surface** messages, with rules for urgent disruptions, human review of uncertain/contradictory posts, and periodic evaluation against new human-labeled samples. That can speed response without losing customer context.

## Part F - Three additional, actionable insights

**F1. Longer negatives:** Observation - negative tweets are longer on average. Evidence - **19.69** words in negative versus **14.01** in positive tweets. Why it matters - longer posts can include operational clues. Action - extract flight number, date, airport, and contact need into agent queues. Confidence/limits - descriptive only; length does not prove urgency.

**F2. Retweet amplification:** Observation - negative tweets receive more recorded retweets in total. Evidence - **857** negative retweets versus **164** positive retweets; **0.80%** of negatives have at least two retweets. Why it matters - some unresolved cases may spread publicly. Action - flag amplified cases for prompt communication. Confidence/limits - unequal tweet volumes, snapshot retweet counts, and retweets are not impressions.

**F3. Geographic blind spots:** Observation - location metadata is often missing. Evidence - **32.3%** of tweet locations and **93.0%** of coordinates are missing. Why it matters - charts cannot reliably identify which airports need help. Action - ask for the flight/airport in follow-ups or use verified booking records. Confidence/limits - missingness is measured, but available free-text locations may also be inaccurate.

