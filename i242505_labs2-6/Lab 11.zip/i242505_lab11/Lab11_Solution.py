"""FAST NUCES - Data Analysis and Visualization - Lab 11.
All lab questions are answered in Lab11_Notebook.ipynb and Director_Brief.pdf.
Run: python Lab11_Solution.py   (keep Tweets.csv in the same folder)
Uses local packages only; no NLTK downloads required.
"""
from __future__ import annotations

import html
import json
import re
from collections import Counter
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from nltk.stem import PorterStemmer
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS, TfidfVectorizer
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, f1_score
from textblob import TextBlob
from textblob.en.inflect import singularize
from wordcloud import WordCloud

BASE = Path(__file__).resolve().parent
CHARTS = BASE / 'charts'
CHARTS.mkdir(exist_ok=True)
LABELS = ['negative', 'neutral', 'positive']
STOP = set(ENGLISH_STOP_WORDS) - {'not', 'no', 'nor', 'never', 'none', 'without', 'cannot', 'cant', 'dont', 'against'}
STOP.update({"i'm", "i've", "i'll", "we're", "we've", "you've", 'just'})
DOMAIN = {'americanair', 'usairways', 'united', 'jetblue', 'southwestair',
          'virginamerica', 'delta', 'airlines', 'airline', 'virgin', 'southwest',
          'american', 'airways', 'amp', 'http', 'https', 'co', 'rt'}
URL_RE = re.compile(r'https?://\S+|www\.\S+', re.I)
HANDLE_RE = re.compile(r'@\w+')
HASHTAG_RE = re.compile(r'#([\w]+)')
REPEAT_RE = re.compile(r'([a-z])\1{2,}', re.I)
WORD_RE = re.compile(r"[a-z]+(?:'[a-z]+)?", re.I)
IRREGULAR = {'flights': 'flight', 'delayed': 'delay', 'cancelled': 'cancel',
             'canceled': 'cancel', 'cancelling': 'cancel', 'canceling': 'cancel',
             'waiting': 'wait', 'running': 'run', 'boarding': 'board',
             'stranded': 'strand', 'missed': 'miss', 'booked': 'book',
             'booking': 'book', 'bags': 'bag', 'luggages': 'luggage',
             'children': 'child', 'better': 'good', 'worst': 'bad'}

sns.set_theme(style='whitegrid', context='notebook')
plt.rcParams.update({'figure.dpi': 110, 'savefig.dpi': 145,
                     'axes.titlesize': 13, 'axes.labelsize': 10})


def normalize(text):
    """Keep meaningful hashtag words, strip links/handles, decode HTML and reduce elongations."""
    text = html.unescape(str(text)).lower()
    # This supplied CSV has expanded-label artifacts in the tweet TEXT, not just
    # its annotation columns (e.g. 'Cancelled Flightled' instead of 'cancelled').
    # Fix only these unambiguous synthetic fragments, never every 'late flight'.
    text = re.sub(r'\bcancelled flight(?:led|ed)\b', 'cancelled', text)
    text = re.sub(r'\bcancelled flighting\b', 'cancelling', text)
    text = re.sub(r'\blate flightrs?\b', 'later', text)
    text = re.sub(r'\breflight booking problems\b', 'rebooking', text)
    text = re.sub(r'\bflight booking problems\b', 'booking', text)
    text = URL_RE.sub(' ', text)
    text = HANDLE_RE.sub(' ', text)
    text = HASHTAG_RE.sub(r'\1', text)
    text = text.replace('won\'t', 'will not').replace('can\'t', 'cannot')
    text = re.sub(r"n['’]t\b", ' not', text)
    text = REPEAT_RE.sub(r'\1\1', text)
    return text


def tokens(text):
    return WORD_RE.findall(text)


def simple_lemma(w):
    """A conservative, transparent rule-based lemma, NOT a full WordNet lemmatizer."""
    if w in IRREGULAR:
        return IRREGULAR[w]
    # Only common plural patterns; no aggressive changes to verbs or negation.
    if len(w) > 4 and w.endswith(('ies', 'sses', 'xes', 'ches', 'shes')):
        return singularize(w)
    if len(w) > 4 and w.endswith('s') and not w.endswith(('ss', 'us', 'is', 'ous')):
        return singularize(w)
    return w


def clean_tokens(text, remove_stop=True, lemmatize=True):
    words = tokens(normalize(text))
    if remove_stop:
        words = [w for w in words if w not in STOP and w not in DOMAIN]
    if lemmatize:
        words = [simple_lemma(w) for w in words]
    return words


def label_from_score(s):
    if s > .1:
        return 'positive'
    if s < -.1:
        return 'negative'
    return 'neutral'


def save(name):
    plt.tight_layout()
    plt.savefig(CHARTS / name, bbox_inches='tight')
    plt.close()


def horizontal_counts(words, title, filename, color='#4479ad', topn=12):
    vals = Counter(words).most_common(topn)
    words_ = [p[0] for p in vals][::-1]
    counts = [p[1] for p in vals][::-1]
    fig, ax = plt.subplots(figsize=(8.4, 5))
    ax.barh(words_, counts, color=color)
    ax.set(xlabel='Number of occurrences', title=title)
    for i, x in enumerate(counts):
        ax.text(x, i, f' {x:,}', va='center', fontsize=8)
    ax.set_xlim(0, max(counts or [1]) * 1.18)
    save(filename)


def describe_audit(steps):
    out = []
    for name, data in steps:
        out.append({'Step': name,
                    'Vocabulary': len(set(w for row in data for w in row)),
                    'Avg words/tweet': round(np.mean([len(row) for row in data]), 2),
                    'Empty tweets': sum(not row for row in data)})
    return pd.DataFrame(out)


def cause_of_error(t):
    """EXPLORATORY keyword tags; sarcasm and intent cannot be validated with regex."""
    t = t.lower()
    if re.search(r'\b(great|love|wonderful|thanks|awesome|fantastic)\b', t) and re.search(
            r'\b(delay|delayed|cancel|cancelled|canceled|stranded|stuck|hold|wait|lost|worst)\b', t):
        return 'Possible sarcasm'
    if re.search(r"\b(not|no|never|nor|cannot|cant|without|nothing|nobody|nowhere)\b|n['’]t\b", t):
        return 'Negation'
    if re.search(r'\b(but|however|although|though|except|yet)\b', t):
        return 'Mixed/contrast'
    if re.search(r'\b(delay|delayed|cancel|cancelled|canceled|stranded|stuck|lost|missed|rebook|baggage|luggage)\b', t):
        return 'Airline operations'
    return 'Other / unclear'


def prepare(df):
    if df['airline_sentiment'].isna().any():
        df = df.dropna(subset=['airline_sentiment']).copy()
    df = df.copy()
    df['text'] = df.text.fillna('').astype(str)
    df['clean_words'] = df.text.map(clean_tokens)
    df['clean_text'] = df.clean_words.map(lambda x: ' '.join(x))
    df['raw_words'] = df.text.map(lambda x: re.findall(r'\b\w+\b', x.lower()))
    df['polarity'] = df.text.map(lambda x: TextBlob(x).sentiment.polarity)
    df['predicted'] = df.polarity.map(label_from_score)
    df['date'] = df.tweet_created.astype(str).str[:10]
    df['word_length'] = df.text.map(lambda x: len(x.split()))
    return df


def analyze(csv_path=None):
    source = Path(csv_path) if csv_path else BASE / 'Tweets.csv'
    df = prepare(pd.read_csv(source))
    result = {'n': len(df), 'dates': [df.date.min(), df.date.max()],
              'class_counts': df.airline_sentiment.value_counts().to_dict(),
              'airline_counts': df.airline.value_counts().to_dict()}

    # A1: examples of tokenizer defects using actual tweets.
    examples = {}
    features = {'handle': r'@\w+', 'hashtag': r'#\w+', 'URL': r'https?://\S+|www\.\S+',
                'emoji': r'[\U0001F300-\U0001FAFF]', 'stretched word': r'([a-z])\1{2,}'}
    for category, pattern in features.items():
        source_text = df.text.map(lambda x: URL_RE.sub(' ', x)) if category == 'stretched word' else df.text
        matching = df[source_text.map(lambda s: bool(re.search(pattern, s, flags=re.I)))]
        text = matching.iloc[0].text if len(matching) else 'Not present'
        examples[category] = {'n_tweets': len(matching), 'original': str(text)[:170],
                              'naive': re.findall(r'\b\w+\b', text.lower())[:20],
                              'cleaned': clean_tokens(text)[:20]}
    result['tokenizer_examples'] = examples
    result['source_artifacts'] = {
        'Cancelled Flightled/ed/ing': int(df.text.str.contains(r'Cancelled Flight(?:led|ed|ing)', case=False, regex=True).sum()),
        'Late Flightr(s)': int(df.text.str.contains(r'Late Flightrs?', case=False, regex=True).sum()),
        'Flight Booking Problems': int(df.text.str.contains('Flight Booking Problems', case=False, regex=False).sum()),
    }

    # A2: removing NOT/NO/NOR from otherwise unchanged text.
    no_neg = df.text.map(lambda x: re.sub(r"\b(not|no|nor|never)\b|n['’]t\b", ' ', x, flags=re.I))
    changed_pred = no_neg.map(lambda x: label_from_score(TextBlob(x).sentiment.polarity))
    changed = changed_pred.ne(df.predicted)
    result['negation_changed'] = int(changed.sum())
    result['negation_example'] = {'with': 'not good', 'without': 'good',
                                  'polarity_with': TextBlob('not good').sentiment.polarity,
                                  'polarity_without': TextBlob('good').sentiment.polarity}

    # A3/A4: vocabulary audit of actual text through cleaning steps.
    raw = df.raw_words.tolist()
    basic = df.text.map(lambda t: tokens(html.unescape(URL_RE.sub(' ', HANDLE_RE.sub(' ', t.lower()))))).tolist()
    norm = df.text.map(lambda t: tokens(normalize(t))).tolist()
    stopped = [[w for w in row if w not in STOP and w not in DOMAIN] for row in norm]
    lemmatized = df.clean_words.tolist()
    audit = describe_audit([('Raw naive tokens', raw), ('Strip links/handles, decode HTML', basic),
                            ('Normalize casing/hashtags/repeats', norm),
                            ('Remove stop and airline filler', stopped),
                            ('Light lemmatization', lemmatized)])
    porter = PorterStemmer()
    stemmed = [[porter.stem(w) for w in row] for row in stopped]
    result['audit'] = audit.to_dict(orient='records')
    result['vocabulary_stemmed'] = len(set(w for row in stemmed for w in row))
    comparisons = ['flights', 'delayed', 'cancelled', 'waiting', 'running',
                   'services', 'better', 'customer', 'united', 'stranded']
    result['lemma_comparison'] = [{'word': w, 'Porter stem': porter.stem(w),
                                   'Light lemma': simple_lemma(w)} for w in comparisons]

    # B5: frequency and domain filler.
    raw_top = Counter(w for row in raw for w in row)
    clean_top = Counter(w for row in lemmatized for w in row)
    result['top_raw'] = raw_top.most_common(16)
    result['top_clean'] = clean_top.most_common(16)
    horizontal_counts([w for row in raw for w in row], 'Most common naive raw tokens (noise visible)',
                      '01_raw_top_words.png', '#929ca7')
    horizontal_counts([w for row in lemmatized for w in row], 'Top cleaned content words (all tweets)',
                      '02_clean_top_words.png')

    # B6: average TF-IDF score differences between positive and negative groups.
    mask = df.airline_sentiment.isin(['negative', 'positive']).values
    docs = df.loc[mask, 'clean_text']
    y = df.loc[mask, 'airline_sentiment'].values
    vectorizer = TfidfVectorizer(min_df=20, max_df=.8, max_features=4000)
    X = vectorizer.fit_transform(docs)
    vocabulary = np.array(vectorizer.get_feature_names_out())
    pos_mean = np.asarray(X[y == 'positive'].mean(axis=0)).ravel()
    neg_mean = np.asarray(X[y == 'negative'].mean(axis=0)).ravel()
    delta = pos_mean - neg_mean
    pos_idx = np.argsort(delta)[-12:][::-1]
    neg_idx = np.argsort(delta)[:12]
    result['tfidf_positive'] = [(str(vocabulary[i]), round(float(delta[i]), 5)) for i in pos_idx]
    result['tfidf_negative'] = [(str(vocabulary[i]), round(float(-delta[i]), 5)) for i in neg_idx]
    fig, axes = plt.subplots(1, 2, figsize=(13, 5.5))
    for ax, ix, measure, title, color in [(axes[0], neg_idx[::-1], -delta, 'Negative-distinctive', '#c85f62'),
                                            (axes[1], pos_idx[::-1], delta, 'Positive-distinctive', '#428b88')]:
        ax.barh(vocabulary[ix], measure[ix], color=color)
        ax.set(xlabel='Average TF-IDF difference', title=title)
    save('03_distinctive_tfidf.png')

    # B7: adjacent word combinations keep local context (stopwords preserve negation).
    neg_words = df.loc[df.airline_sentiment.eq('negative'), 'clean_words']
    bi = Counter(' '.join(pair) for row in neg_words for pair in zip(row, row[1:]))
    tri = Counter(' '.join(pair) for row in neg_words for pair in zip(row, row[1:], row[2:]))
    result['top_bigrams'] = bi.most_common(20)
    result['top_trigrams'] = tri.most_common(12)
    fig, axes = plt.subplots(1, 2, figsize=(14, 5.2))
    for ax, values, title, color in [(axes[0], bi, 'Negative tweet bigrams', '#c86b5a'),
                                    (axes[1], tri, 'Negative tweet trigrams', '#7c8eb0')]:
        ranked = values.most_common(12)[::-1]
        ax.barh([v[0] for v in ranked], [v[1] for v in ranked], color=color)
        ax.set(xlabel='Count', title=title)
    save('04_negative_ngrams.png')
    result['phrases_count'] = {p: int(df.loc[df.airline_sentiment.eq('negative'), 'text']
                                      .str.contains(p, case=False, regex=False).sum())
                               for p in ['customer service', 'cancelled flight', 'no help', 'not happy']}

    # B8: word cloud vs precise bar chart for exactly same word counts.
    negative_word_counts = Counter(w for row in neg_words for w in row)
    result['top_negative'] = negative_word_counts.most_common(16)
    # Back-to-back (butterfly) count chart: shared key terms, one scale per word.
    key_words = ['flight', 'service', 'thank', 'not', 'delay', 'hour', 'good', 'great', 'help']
    positive_word_counts = Counter(w for row in df.loc[df.airline_sentiment.eq('positive'), 'clean_words'] for w in row)
    neg_values = [negative_word_counts[w] for w in key_words]
    pos_values = [positive_word_counts[w] for w in key_words]
    fig, ax = plt.subplots(figsize=(10.8, 5))
    ax.barh(key_words, [-n for n in neg_values], color='#c66d6b', label='Negative tweets')
    ax.barh(key_words, pos_values, color='#469890', label='Positive tweets')
    ax.axvline(0, color='#343b46', linewidth=1)
    from matplotlib.ticker import FuncFormatter
    ax.xaxis.set_major_formatter(FuncFormatter(lambda n, _: f'{abs(int(n)):,}'))
    ax.set(xlabel='Number of word occurrences (absolute scale on both sides)',
           title='Butterfly comparison: words in negative vs positive tweets')
    ax.legend(loc='lower right')
    save('13_butterfly_words.png')
    fig, axes = plt.subplots(1, 2, figsize=(14, 5.2))
    vals = negative_word_counts.most_common(13)[::-1]
    axes[0].barh([x[0] for x in vals], [x[1] for x in vals], color='#c66568')
    axes[0].set(xlabel='Exact word count', title='Negative words: bar chart')
    wc = WordCloud(width=700, height=420, background_color='white', max_words=100,
                   colormap='Reds', random_state=42).generate_from_frequencies(negative_word_counts)
    axes[1].imshow(wc, interpolation='bilinear')
    axes[1].axis('off')
    axes[1].set_title('Same negative words: cloud (relative emphasis)')
    save('05_negative_bar_vs_cloud.png')

    # C9: score every tweet with TextBlob lexicon polarity.
    y_true = df.airline_sentiment
    y_pred = df.predicted
    cm = confusion_matrix(y_true, y_pred, labels=LABELS)
    details = classification_report(y_true, y_pred, labels=LABELS, output_dict=True,
                                    zero_division=0)
    result['accuracy'] = float(accuracy_score(y_true, y_pred))
    result['macro_f1'] = float(f1_score(y_true, y_pred, labels=LABELS, average='macro'))
    result['class_report'] = {s: {'precision': details[s]['precision'],
                                  'recall': details[s]['recall'],
                                  'f1': details[s]['f1-score']} for s in LABELS}
    result['confusion_matrix'] = cm.tolist()
    fig, ax = plt.subplots(figsize=(7.2, 5.4))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=LABELS,
                yticklabels=LABELS, ax=ax)
    ax.set(xlabel='TextBlob predicted sentiment', ylabel='Human label',
           title=f'TextBlob agreement = {result["accuracy"]:.1%}; macro F1 = {result["macro_f1"]:.2f}')
    save('06_sentiment_confusion_matrix.png')

    # C10: focused label disagreements and crude regex cause diagnostics.
    mistakes = df.loc[df.predicted.ne(df.airline_sentiment)].copy()
    mistakes['cause'] = mistakes.text.map(cause_of_error)
    result['mistakes_n'] = int(len(mistakes))
    result['error_causes'] = mistakes.cause.value_counts().to_dict()
    missed_negative = mistakes[mistakes.airline_sentiment.eq('negative')]
    result['negative_misses'] = len(missed_negative)
    result['negative_miss_causes'] = missed_negative.cause.value_counts().to_dict()
    worst = missed_negative.sort_values('polarity', ascending=False).head(8)
    result['biggest_disagreements'] = [
        {'text': row.text[:160], 'human': row.airline_sentiment,
         'prediction': row.predicted, 'polarity': round(row.polarity, 3),
         'possible_cause': cause_of_error(row.text)} for row in worst.itertuples()]
    counts = mistakes.cause.value_counts().sort_values()
    fig, ax = plt.subplots(figsize=(8.8, 4.6))
    ax.barh(counts.index, counts.values, color='#c3736c')
    ax.set(title='Heuristic tags for model/human disagreements', xlabel='Tweets (categories are approximate)')
    save('07_error_cause_tags.png')

    # C11: own constructed hard cases with obvious intended negativity.
    constructed = [
        'Great, another cancelled flight. Just what I needed.',
        'My flight was cancelled and nobody helped us.',
        'I love being stranded overnight. Amazing.'
    ]
    result['constructed_tweets'] = [
        {'text': t, 'intended': 'negative', 'score': round(TextBlob(t).sentiment.polarity, 3),
         'model': label_from_score(TextBlob(t).sentiment.polarity)} for t in constructed]

    # C12: sensitivity to confidence of HUMAN-provided labels.
    high = df.loc[df.airline_sentiment_confidence >= .90]
    result['high_conf_n'] = int(len(high))
    result['high_conf_accuracy'] = float(accuracy_score(high.airline_sentiment, high.predicted))
    result['high_conf_macro_f1'] = float(f1_score(high.airline_sentiment, high.predicted,
                                                labels=LABELS, average='macro'))
    result['high_conf_class_report'] = classification_report(
        high.airline_sentiment, high.predicted, labels=LABELS, output_dict=True, zero_division=0)

    # D13: categories of airline-specific negative comments, normalize by airline volume.
    ndf = df.loc[df.airline_sentiment.eq('negative')].copy()
    ndf['negativereason'] = ndf.negativereason.fillna('Not tagged')
    ct_reason = pd.crosstab(ndf.airline, ndf.negativereason)
    reason_pct = ct_reason.div(ct_reason.sum(axis=1), axis=0) * 100
    result['reason_pct'] = reason_pct.round(2).to_dict(orient='index')
    fig, ax = plt.subplots(figsize=(13.5, 5.7))
    sns.heatmap(reason_pct, annot=True, fmt='.0f', cmap='YlOrRd', linewidths=.3,
                cbar_kws={'label': '% of negative tweets'}, ax=ax)
    ax.set(title='Complaint-reason mix among negative tweets by airline', xlabel='', ylabel='')
    ax.tick_params(axis='x', labelrotation=45)
    save('08_airline_complaint_heatmap.png')
    # Merge labels into service, operations, booking and other for easy comparison.
    service = ['Customer Service Issue', 'Flight Attendant Complaints']
    operations = ['Late Flight', 'Cancelled Flight', 'Lost Luggage',
                  'Damaged Luggage', 'Bad Flight', 'longlines']
    group_map = {**{x: 'Customer service' for x in service},
                 **{x: 'Operations' for x in operations},
                 'Flight Booking Problems': 'Booking'}
    ndf['complaint_group'] = ndf.negativereason.map(group_map).fillna('Other/unclear')
    grp = pd.crosstab(ndf.airline, ndf.complaint_group).reindex(columns=[
        'Customer service', 'Operations', 'Booking', 'Other/unclear'], fill_value=0)
    grp_pct = grp.div(grp.sum(axis=1), axis=0) * 100
    result['complaint_group_pct'] = grp_pct.round(2).to_dict(orient='index')
    fig, ax = plt.subplots(figsize=(9.8, 5.3))
    grp_pct.plot.barh(stacked=True, ax=ax, color=['#508d97', '#d58b62', '#8e88aa', '#b6c0c6'])
    ax.set(xlabel='% of negative tweets', ylabel='', title='Service versus operations complaints (within airline)')
    ax.legend(loc='upper center', bbox_to_anchor=(.5, -0.14), ncol=4, fontsize=9)
    save('09_airline_reason_stacked.png')

    # D14: counts and shares are not the same measurement.
    airline_table = pd.crosstab(df.airline, df.airline_sentiment).reindex(columns=LABELS)
    airline_table['total'] = airline_table.sum(axis=1)
    airline_table['negative_rate'] = airline_table.negative / airline_table.total
    result['airline_metrics'] = airline_table.round(4).to_dict(orient='index')
    sentiment_share = airline_table[LABELS].div(airline_table.total, axis=0) * 100
    fig, ax = plt.subplots(figsize=(9.5, 4.8))
    sentiment_share.plot.barh(stacked=True, ax=ax, color=['#cf7471', '#aeb9c1', '#4c9a8b'])
    ax.set(title='Sentiment mix by airline (each airline = 100%)', xlabel='Percent of tweets', ylabel='')
    ax.legend(title='Human sentiment', loc='upper center', bbox_to_anchor=(.5, -0.16), ncol=3)
    save('14_stacked_airline_sentiment.png')
    fig, axes = plt.subplots(1, 2, figsize=(13.2, 5))
    airline_table.sort_values('negative').negative.plot.barh(ax=axes[0], color='#8a98b0')
    axes[0].set(title='Number of negative tweets', xlabel='Tweets', ylabel='')
    (airline_table.sort_values('negative_rate').negative_rate * 100).plot.barh(ax=axes[1], color='#be6d6b')
    axes[1].set(title='Negative share of each airline tweets', xlabel='Percent (%)', ylabel='')
    save('10_airline_negative_count_vs_rate.png')

    # D15: time variation, avoiding unjustified causation.
    day = pd.crosstab(df.date, df.airline_sentiment)
    day['all_tweets'] = day.sum(axis=1)
    day['negative_rate'] = day.negative / day.all_tweets
    result['daily_metrics'] = day.round(4).to_dict(orient='index')
    fig, ax = plt.subplots(figsize=(10.2, 4.6))
    day[['negative', 'neutral', 'positive']].plot(kind='bar', stacked=True, ax=ax,
                                                color=['#cf7471', '#a9b2bc', '#4c9a8b'])
    ax.set(title='Tweets by date and human-labeled sentiment (February 2015)',
           xlabel='Date shown in file', ylabel='Number of tweets')
    ax.legend(title='Human label', fontsize=9)
    save('11_sentiment_over_time.png')
    fig, ax = plt.subplots(figsize=(9.3, 4.5))
    valid_days = day[day.all_tweets >= 100]
    ax.plot(valid_days.index, valid_days.negative_rate * 100, 'o-', linewidth=2, color='#b66062')
    ax.set(title='Negative share each day (excluding partial 4-tweet first day)',
           ylabel='Percent negative', xlabel='Date', ylim=(0, 100))
    ax.tick_params(axis='x', labelrotation=30)
    save('12_daily_negative_rate.png')

    # D16: illustrative historical triage, using only available columns.
    urgent_reason = {'Cancelled Flight', 'Late Flight', 'Lost Luggage'}
    urgent_text = df.text.str.contains(r'\b(?:stranded|stuck|today|tonight|missed connection|now|tomorrow)\b',
                                       case=False, regex=True)
    disrupted = df.negativereason.isin(urgent_reason)
    high_reach = df.retweet_count.ge(2)
    negative = df.airline_sentiment.eq('negative')
    df['priority'] = np.select([negative & disrupted & (high_reach | urgent_text),
                                negative & (disrupted | high_reach), negative],
                               ['P1 urgent', 'P2 review', 'P3 routine'], default='Not negative')
    result['priority_counts'] = df.priority.value_counts().to_dict()
    result['priority_example'] = [
        {'airline': r.airline, 'reason': str(r.negativereason),
         'retweets': int(r.retweet_count), 'tweet': r.text[:140]}
        for r in df[df.priority.eq('P1 urgent')].sort_values('retweet_count', ascending=False)
        .head(5).itertuples()]

    # E/F: extra, data-grounded director insights.
    result['duplicates_text'] = int(df.text.duplicated().sum())
    result['missing_location_pct'] = float(df.tweet_location.isna().mean() * 100)
    result['missing_coord_pct'] = float(df.tweet_coord.isna().mean() * 100)
    result['retweets_by_class'] = df.groupby('airline_sentiment').retweet_count.agg(['sum', 'mean', 'max']).round(3).to_dict(orient='index')
    result['word_len_by_class'] = df.groupby('airline_sentiment').word_length.agg(['mean', 'median']).round(2).to_dict(orient='index')
    result['negative_high_reach_pct'] = float(df.loc[negative, 'retweet_count'].ge(2).mean() * 100)
    result['neg_pct'] = float(negative.mean() * 100)
    result['label_conf_mean'] = df.groupby('airline_sentiment').airline_sentiment_confidence.mean().round(3).to_dict()
    result['ready_charts'] = [p.name for p in sorted(CHARTS.glob('*.png'))]

    with (BASE / 'analysis_results.json').open('w', encoding='utf-8') as f:
        json.dump(result, f, indent=2, ensure_ascii=False)
    return df, result


if __name__ == '__main__':
    data, summary = analyze()
    print('Done. Tweets:', summary['n'], '| charts:', len(summary['ready_charts']))
    print('TextBlob accuracy:', f"{summary['accuracy']:.1%}")
    print('Airlines negative shares:')
    for name, values in summary['airline_metrics'].items():
        print(f" {name:16} {values['negative_rate']:.1%}")
    print('Saved charts in:', CHARTS)
