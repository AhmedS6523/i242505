# DAV Lab 11 - submission

Files:
- `Lab11_Notebook.ipynb`: all questions A1-E19 and three Part F insights, charts, tables and explanations.
- `Lab11_Solution.py`: standalone Python implementation; generates the charts and `analysis_results.json`.
- `Tweets.csv`: dataset supplied with the lab.
- `Director_Brief.pdf`: required one-page non-technical executive brief.
- `Lab11_Answers.md`: concise written answers and chart references.
- `charts/`: 14 generated figures. All data comes from Tweets.csv.

**To use:**
1. Install dependencies if necessary: `pip install -r requirements.txt`
2. Open `Lab11_Notebook.ipynb`, then run all cells; OR run `python Lab11_Solution.py` from this folder.
3. Keep the CSV, notebook, and .py file together.

The original data has 14,640 tweets, dates in February 2015. TextBlob is a simple lexicon-based baseline, not a production model. The transparent rule-based lemmatizer avoids downloading any NLTK corpora. Source-text artifacts such as `Cancelled Flightled` are corrected only when unambiguous, while the original tweets are kept for sentiment.

**Submit:** upload the Python file to your section GitHub repo under `RollNumber_Section` inside the week's folder, and upload a single ZIP to GCR. Rename the ZIP to `RollNumber_Section_Lab11.zip` using your actual roll number and section. Both GCR and GitHub are required by the manual.
