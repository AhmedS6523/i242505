"use strict";
/* Lab 10 – Time series in D3: Islamabad air quality 2025
   Pipeline:  "2025-03-11" (text) -> Date (d3.timeParse) -> pixel (d3.scaleTime) -> line/area/axis */

const COLOR = { city: "#1b4f8a", suburb: "#d9622b", ma: "#0b1f3a", daily: "#8fb0da",
                guide: "#2e8b57", target: "#c0392b", gap: "#dde2e8" };
const LEVELS = [
  { key: "Low",      label: "Low (35 or below)", color: "#fbe7a1" },
  { key: "Moderate", label: "Moderate (36–75)",  color: "#f4a259" },
  { key: "High",     label: "High (76–150)",     color: "#d1432b" },
  { key: "Severe",   label: "Severe (above 150)",color: "#5b0e1f" }
];
const MONTHS = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
const MONTHS_LONG = ["January","February","March","April","May","June","July","August","September","October","November","December"];
const WEEKDAYS = ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"];
const DAY = 864e5;

const fmtDate = d3.timeFormat("%-d %b %Y");
const fmtShort = d3.timeFormat("%-d %b");
const f1 = d3.format(".1f");
const f0 = d3.format(".0f");
const pct = v => d3.format(".1f")(v * 100) + "%";
const level = v => v <= 35 ? "Low" : v <= 75 ? "Moderate" : v <= 150 ? "High" : "Severe";
const weekdayIdx = d => (d.date.getDay() + 6) % 7;           // Monday = 0
const joinList = a => a.length < 2 ? a.join("") : a.slice(0, -1).join(", ") + " and " + a[a.length - 1];

const tip = d3.select("#tip");
function showTip(html, event) {
  tip.html(html).style("opacity", 1);
  const r = tip.node().getBoundingClientRect();
  let left = event.clientX + 14, top = event.clientY - r.height - 10;
  if (left + r.width > window.innerWidth - 8) left = event.clientX - r.width - 14;
  if (top < 8) top = event.clientY + 18;
  tip.style("left", left + "px").style("top", top + "px");
}
const hideTip = () => tip.style("opacity", 0);

/* ---------- loading and preparation ---------- */
const parseDate = d3.timeParse("%Y-%m-%d");
d3.csv("dataset/air_quality_2025.csv", d => ({
  date: parseDate(d.date), city: +d.pm25_city, suburb: +d.pm25_suburb, temp: +d.temp_c
})).then(raw => {
  const rows = raw.filter(d => d.date && isFinite(d.city) && isFinite(d.suburb))
                  .sort((a, b) => a.date - b.date);
  if (!rows.length) throw new Error("The CSV loaded but contains no valid rows.");
  const S = buildStats(rows, raw.length);
  const steps = [renderHeadlines, task1, task2, task3, task4, task5, task6, task7, task8, task9, answers];
  steps.forEach(fn => {
    try { fn(S); } catch (err) {
      console.error(fn.name, err);
      const box = document.createElement("div");
      box.className = "error"; box.textContent = fn.name + " failed: " + err.message;
      document.querySelector("main").prepend(box);
    }
  });
}).catch(err => {
  console.error(err);
  document.getElementById("load-error").innerHTML =
    '<div class="error"><b>The data could not be loaded.</b> Open this page through a local server (for example VS Code Live Server), ' +
    'and keep <code>dataset/air_quality_2025.csv</code> next to <code>index.html</code>. Details: ' + String(err.message) + '</div>';
});

function segmentsOf(rows) {            // continuous stretches: a new one starts after any missing day
  const segs = []; let cur = [];
  rows.forEach((r, i) => {
    if (i > 0 && d3.timeDay.count(rows[i - 1].date, r.date) > 1) { segs.push(cur); cur = []; }
    cur.push(r);
  });
  if (cur.length) segs.push(cur);
  return segs;
}
function corr(a, b) {
  const ma = d3.mean(a), mb = d3.mean(b); let n = 0, da = 0, db = 0;
  a.forEach((v, i) => { n += (v - ma) * (b[i] - mb); da += (v - ma) ** 2; db += (b[i] - mb) ** 2; });
  return n / Math.sqrt(da * db);
}

function buildStats(rows, rawCount) {
  const S = { rows, rawCount };
  S.n = rows.length;
  S.first = rows[0].date; S.last = rows[rows.length - 1].date;
  S.calDays = d3.timeDay.count(new Date(2025, 0, 1), new Date(2026, 0, 1));    // 365
  S.gaps = [];
  rows.forEach((r, i) => {
    if (i === 0) return;
    const k = d3.timeDay.count(rows[i - 1].date, r.date);
    if (k > 1) S.gaps.push({ lastBefore: rows[i - 1], firstAfter: r, start: d3.timeDay.offset(rows[i - 1].date, 1),
                              end: d3.timeDay.offset(r.date, -1), missing: k - 1 });
  });
  S.missing = d3.sum(S.gaps, g => g.missing);
  S.segs = segmentsOf(rows);

  // 7-day moving average (d3.mean over each day and the previous six), never across a gap
  S.segs.forEach(seg => seg.forEach((r, i) => { r.ma = d3.mean(seg.slice(Math.max(0, i - 6), i + 1), d => d.city); }));

  // Task 2 / 3 numbers
  S.above15 = rows.filter(d => d.city > 15).length;
  S.above75 = rows.filter(d => d.city > 75).length;
  const cum = d3.cumsum(rows, d => d.city > 75 ? 1 : 0);
  rows.forEach((r, i) => { r.cum = cum[i]; r.level = level(r.city); });
  S.top = [...rows].sort((a, b) => b.city - a.city).slice(0, 3);
  S.lowDays = rows.filter(d => d.city <= 15);

  // monthly summaries
  S.months = d3.range(12).map(mi => {
    const rs = rows.filter(r => r.date.getMonth() === mi);
    const start = new Date(2025, mi, 1), next = new Date(2025, mi + 1, 1);
    const lv = {}; LEVELS.forEach(L => lv[L.key] = rs.filter(r => r.level === L.key).length);
    const minR = rs.reduce((a, b) => b.city < a.city ? b : a), maxR = rs.reduce((a, b) => b.city > a.city ? b : a);
    return { mi, name: MONTHS[mi], long: MONTHS_LONG[mi], rows: rs, n: rs.length, cal: d3.timeDay.count(start, next),
      start, next, mid: new Date(2025, mi, 15), min: minR.city, max: maxR.city, minRow: minR, maxRow: maxR,
      mean: d3.mean(rs, r => r.city), subMean: d3.mean(rs, r => r.suburb), tempMean: d3.mean(rs, r => r.temp),
      gapMean: d3.mean(rs, r => r.city - r.suburb), above75: rs.filter(r => r.city > 75).length,
      range: maxR.city - minR.city, lv };
  });
  S.byMean = [...S.months].sort((a, b) => b.mean - a.mean);
  S.bySpread = [...S.months].sort((a, b) => b.range - a.range);
  S.sevTotal = d3.sum(S.months, m => m.lv.Severe);

  // weekday x month grid (d3.rollup)
  S.heat = d3.rollup(rows, v => ({ mean: d3.mean(v, d => d.city), n: v.length }), d => d.date.getMonth(), d => weekdayIdx(d));
  S.wdMean = d3.range(7).map(w => d3.mean(rows.filter(r => weekdayIdx(r) === w), r => r.city));
  S.overall = d3.mean(rows, r => r.city);

  S.rCitySub = corr(rows.map(r => r.city), rows.map(r => r.suburb));
  S.rCityTemp = corr(rows.map(r => r.city), rows.map(r => r.temp));
  S.subLower = rows.filter(r => r.suburb < r.city).length;
  S.subMeanAll = d3.mean(rows, r => r.suburb);
  S.maxDiff = rows.reduce((a, b) => (b.city - b.suburb) > (a.city - a.suburb) ? b : a);

  // longest run of recorded days at or below 75 (the flat part of the build-up curve)
  let best = null, run = [];
  rows.forEach((r, i) => {
    const contiguous = run.length && d3.timeDay.count(run[run.length - 1].date, r.date) === 1;
    if (r.city <= 75 && (!run.length || contiguous)) run.push(r);
    else { run = r.city <= 75 ? [r] : []; }
    if (run.length && (!best || run.length > best.length)) best = [...run];
  });
  S.flat = best;
  return S;
}

/* ---------- shared drawing helpers ---------- */
let uid = 0;
function makeSvg(sel, { W = 960, H = 400, m = { top: 22, right: 28, bottom: 38, left: 58 }, label = "" } = {}) {
  const svg = d3.select(sel).append("svg").attr("viewBox", `0 0 ${W} ${H}`).attr("role", "img").attr("aria-label", label);
  const g = svg.append("g").attr("transform", `translate(${m.left},${m.top})`);
  return { svg, g, w: W - m.left - m.right, h: H - m.top - m.bottom, m, W, H };
}
const monthAxis = (x) => d3.axisBottom(x).ticks(d3.timeMonth.every(1)).tickFormat(d3.timeFormat("%b"));
function drawAxes(c, x, y, ylabel) {
  c.g.append("g").attr("class", "grid").call(d3.axisLeft(y).ticks(6).tickSize(-c.w).tickFormat(""));
  c.g.append("g").attr("class", "axis").attr("transform", `translate(0,${c.h})`).call(monthAxis(x));
  c.g.append("g").attr("class", "axis").call(d3.axisLeft(y).ticks(6));
  c.svg.append("text").attr("class", "ylab").attr("transform", "rotate(-90)").attr("x", -(c.m.top + c.h / 2)).attr("y", 16)
    .attr("text-anchor", "middle").text(ylabel);
}
function addHatch(svg) {
  const id = "hatch" + (++uid);
  const p = svg.append("defs").append("pattern").attr("id", id).attr("width", 6).attr("height", 6)
    .attr("patternUnits", "userSpaceOnUse").attr("patternTransform", "rotate(45)");
  p.append("rect").attr("width", 6).attr("height", 6).attr("fill", "#eef1f4");
  p.append("line").attr("y2", 6).attr("stroke", "#b4bfcb").attr("stroke-width", 2);
  return `url(#${id})`;
}
function drawGaps(c, x, S, { label = false } = {}) {          // shade the dates with no reading
  const fill = addHatch(c.svg);
  const sel = c.g.append("g").attr("class", "gaps");
  S.gaps.forEach(gp => {
    const x0 = x(gp.lastBefore.date), x1 = x(gp.firstAfter.date);
    sel.append("rect").attr("x", x0).attr("width", x1 - x0).attr("height", c.h).attr("fill", fill).attr("opacity", .95);
    sel.append("line").attr("x1", x0).attr("x2", x0).attr("y2", c.h).attr("stroke", "#9aa5b1").attr("stroke-dasharray", "2 2");
    sel.append("line").attr("x1", x1).attr("x2", x1).attr("y2", c.h).attr("stroke", "#9aa5b1").attr("stroke-dasharray", "2 2");
    if (label) {
      const cx = (x0 + x1) / 2;
      sel.append("text").attr("class", "ann halo").attr("x", cx).attr("y", 14).attr("text-anchor", "middle").text("No data: sensor offline");
      sel.append("text").attr("class", "halo").attr("x", cx).attr("y", 29).attr("text-anchor", "middle")
        .style("font", "11px system-ui").style("fill", "#566371").text(`${gp.missing} days missing`);
    }
  });
  return sel;
}
function drawSegments(parent, S, x, y, val, attrs) {          // one path per unbroken stretch
  const line = d3.line().x(d => x(d.date)).y(d => y(val(d)));
  const sel = parent.append("g").attr("fill", "none").attr("stroke-linejoin", "round").attr("stroke-linecap", "round");
  Object.entries(attrs).forEach(([k, v]) => sel.attr(k, v));
  sel.selectAll("path").data(S.segs).join("path").attr("d", s => line(s));
  return { sel, line, redraw() { sel.selectAll("path").attr("d", s => line(s)); } };
}
function addHover(c, x, rows, series, html) {
  const bis = d3.bisector(d => d.date).center;
  const focus = c.g.append("g").style("display", "none").attr("pointer-events", "none");
  const vline = focus.append("line").attr("class", "hover-line").attr("y1", 0).attr("y2", c.h);
  const dots = focus.selectAll("circle").data(series).join("circle").attr("r", 4.5).attr("fill", "#fff")
    .attr("stroke", s => s.color).attr("stroke-width", 2);
  c.g.append("rect").attr("width", c.w).attr("height", c.h).attr("fill", "none").attr("pointer-events", "all")
    .on("pointermove", event => {
      const [mx] = d3.pointer(event);
      const when = x.invert(mx);
      if (when < x.domain()[0] || when > x.domain()[1]) return;
      const d = rows[bis(rows, when)];
      focus.style("display", null);
      if (Math.abs(d.date - when) > 1.5 * DAY) {                   // between two readings that are more than a day apart
        vline.attr("x1", mx).attr("x2", mx); dots.style("display", "none");
        showTip(`<b>${fmtDate(when)}</b><br>No data: sensor offline`, event); return;
      }
      vline.attr("x1", x(d.date)).attr("x2", x(d.date));
      dots.style("display", null).attr("cx", x(d.date)).attr("cy", (s) => s.y(s.val(d)));
      showTip(html(d), event);
    })
    .on("pointerleave", () => { focus.style("display", "none"); hideTip(); });
}
function refLines(c, y, { labelX = 6, onlyIfVisible = false } = {}) {
  const defs = [{ v: 15, color: COLOR.guide, text: "WHO 24-hour guideline: 15 µg/m³" },
                { v: 75, color: COLOR.target, text: "Interim target 1: 75 µg/m³" }];
  const gr = c.g.append("g");
  const items = defs.map(d => {
    const l = gr.append("line").attr("x1", 0).attr("x2", c.w).attr("stroke", d.color).attr("stroke-width", 1.5).attr("stroke-dasharray", "7 5");
    const t = gr.append("text").attr("class", "ann halo").attr("x", labelX).attr("dy", -5).style("fill", d.color).text(d.text);
    return { d, l, t };
  });
  const place = () => items.forEach(({ d, l, t }) => {
    const vis = y(d.v) >= 0 && y(d.v) <= c.h;
    l.attr("y1", y(d.v)).attr("y2", y(d.v)).style("display", vis ? null : "none");
    t.attr("y", y(d.v)).style("display", vis ? null : "none");
  });
  place();
  return place;
}

/* ---------- headline strip ---------- */
function renderHeadlines(S) {
  const worst = S.byMean[0], best = S.byMean[11];
  const items = [
    [`${worst.name} vs ${best.name}`, `Worst month averages ${f1(worst.mean)} µg/m³, ${f1(worst.mean / best.mean)}× the best month (${f1(best.mean)})`],
    [`${S.above75} of ${S.n} days`, `above the 75 µg/m³ interim target (${pct(S.above75 / S.n)})`],
    [`${S.top[0].city.toFixed(0)} µg/m³`, `highest day, ${fmtDate(S.top[0].date)}, an isolated spike`],
    [`${S.missing} days missing`, `sensor offline ${fmtShort(S.gaps[0].start)}–${fmtShort(S.gaps[0].end)}`]
  ];
  d3.select("#headlines").selectAll("div").data(items).join("div")
    .html(d => `<b>${d[0]}</b>${d[1]}`);
}

/* ---------- Task 1 ---------- */
function task1(S) {
  const g0 = S.gaps[0];
  const cards = [
    ["Rows in the file", S.n, false], ["First date", fmtDate(S.first), false], ["Last date", fmtDate(S.last), false],
    ["Days in 2025", S.calDays, false], ["Missing days", S.calDays - S.n, true]
  ];
  d3.select("#t1-cards").selectAll("div").data(cards).join("div").attr("class", d => "card" + (d[2] ? " warn" : ""))
    .html(d => `<small>${d[0]}</small><b>${d[1]}</b>`);
  const gapText = S.gaps.length
    ? `The ${S.missing} absent days are one unbroken stretch, ${fmtDate(g0.start)} to ${fmtDate(g0.end)}: the file jumps from ${fmtDate(g0.lastBefore.date)} straight to ${fmtDate(g0.firstAfter.date)}.`
    : "No dates are missing.";
  d3.select("#t1-read").html(
    `<p><b>What I notice:</b> a full year has ${S.calDays} days but the file has ${S.n} rows, so ${S.calDays - S.n} days have no reading. ${gapText} ` +
    `The file starts on 1 Jan and ends on 31 Dec, so there are no gaps at either end, no duplicate dates, and no blank values. ` +
    `Nothing in the file marks the outage: the rows simply do not exist, which is why a chart that spaces rows evenly would hide it. ` +
    `Every time chart below therefore places each reading at its true date and breaks the line over these days.</p>`);
  let h = '<table class="data"><tr><th>date</th><th>pm25_city</th><th>pm25_suburb</th><th>temp_c</th></tr>';
  [S.rows[0], S.rows[1], null, g0.lastBefore, "gap", g0.firstAfter].forEach(r => {
    if (r === null) h += '<tr><td colspan="4" style="text-align:center">…</td></tr>';
    else if (r === "gap") h += `<tr class="gaprow"><td colspan="4">${S.missing} days missing (${fmtShort(g0.start)} to ${fmtShort(g0.end)})</td></tr>`;
    else h += `<tr><td>${d3.timeFormat("%Y-%m-%d")(r.date)}</td><td>${r.city}</td><td>${r.suburb}</td><td>${r.temp}</td></tr>`;
  });
  d3.select("#t1-table").html(h + "</table>");
}

/* ---------- Task 2 ---------- */
function task2(S) {
  const c = makeSvg("#t2-chart", { H: 410, label: "Daily city-centre PM2.5 through 2025 with reference lines at 15 and 75" });
  const x = d3.scaleTime().domain(d3.extent(S.rows, d => d.date)).range([0, c.w]);
  const y = d3.scaleLinear().domain([0, d3.max(S.rows, d => d.city) * 1.06]).nice().range([c.h, 0]);
  drawAxes(c, x, y, "PM2.5 (µg/m³)");
  drawGaps(c, x, S);
  refLines(c, y);
  drawSegments(c.g, S, x, y, d => d.city, { stroke: COLOR.city, "stroke-width": 1.6 });
  const top2 = S.top.slice(0, 2);
  c.g.selectAll("circle.top").data(top2).join("circle").attr("class", "top").attr("cx", d => x(d.date)).attr("cy", d => y(d.city))
    .attr("r", 5.5).attr("fill", COLOR.target).attr("stroke", "#fff").attr("stroke-width", 1.5);
  c.g.selectAll("text.toplab").data(top2).join("text").attr("class", "ann halo toplab").attr("x", d => x(d.date) - 9).attr("y", d => y(d.city) + 4)
    .attr("text-anchor", "end").text(d => `${fmtShort(d.date)} · ${f1(d.city)} µg/m³`);
  addHover(c, x, S.rows, [{ val: d => d.city, y, color: COLOR.city }],
    d => `<b>${fmtDate(d.date)}</b><br>City PM2.5: ${f1(d.city)} µg/m³<br>Level: ${d.level}`);
  d3.select("#t2-chips").selectAll("span").data([
    [`Days above 15 µg/m³`, `${S.above15} of ${S.n} (${pct(S.above15 / S.n)})`],
    [`Days above 75 µg/m³`, `${S.above75} of ${S.n} (${pct(S.above75 / S.n)})`]
  ]).join("span").attr("class", "chip").html(d => `${d[0]}: <b>${d[1]}</b>`);
  const low = S.lowDays.map(d => `${fmtShort(d.date)} (${f1(d.city)})`);
  d3.select("#t2-read").html(
    `The line is high in winter, falls steeply through April–June to a summer floor, and climbs back from September. ` +
    `${S.above15} of ${S.n} recorded days are over the WHO guideline; the only ${S.lowDays.length === 1 ? "day" : "days"} at or below it ${S.lowDays.length === 1 ? "was" : "were"} ${joinList(low)}. ` +
    `The two highest days, ${fmtDate(top2[0].date)} and ${fmtDate(top2[1].date)}, are single-day spikes. The hatched band is the sensor outage.`);
}

/* ---------- Task 3 ---------- */
function task3(S) {
  const c = makeSvg("#t3-chart", { H: 380, label: "Running total of days above 75 micrograms per cubic metre" });
  const x = d3.scaleTime().domain(d3.extent(S.rows, d => d.date)).range([0, c.w]);
  const y = d3.scaleLinear().domain([0, S.above75 * 1.05]).nice().range([c.h, 0]);
  drawAxes(c, x, y, "Days above 75 µg/m³ so far");
  drawGaps(c, x, S);
  c.g.append("path").datum(S.rows).attr("fill", "#d1432b").attr("fill-opacity", .28)
    .attr("d", d3.area().x(d => x(d.date)).y0(c.h).y1(d => y(d.cum)));
  c.g.append("path").datum(S.rows).attr("fill", "none").attr("stroke", "#b3321c").attr("stroke-width", 2)
    .attr("d", d3.line().x(d => x(d.date)).y(d => y(d.cum)));
  const last = S.rows[S.rows.length - 1];
  c.g.append("circle").attr("cx", x(last.date)).attr("cy", y(last.cum)).attr("r", 5).attr("fill", "#b3321c");
  c.g.append("text").attr("class", "ann halo").attr("x", x(last.date) - 10).attr("y", y(last.cum) - 8).attr("text-anchor", "end")
    .text(`${last.cum} days by 31 Dec`);
  addHover(c, x, S.rows, [{ val: d => d.cum, y, color: "#b3321c" }],
    d => `<b>${fmtDate(d.date)}</b><br>Unhealthy days so far: ${d.cum}<br>That day: ${f1(d.city)} µg/m³`);
  const ok = last.cum === S.above75;
  d3.select("#t3-chips").selectAll("span").data([
    ["Final running total", `${last.cum}`], ["Task 2 count above 75", `${S.above75}`], ["Match", ok ? "yes ✓" : "NO ✗"]
  ]).join("span").attr("class", "chip").html(d => `${d[0]}: <b>${d[1]}</b>`);
  const full = S.months.filter(m => m.above75 === m.n).map(m => m.name), none = S.months.filter(m => m.above75 === 0).map(m => m.name);
  d3.select("#t3-read").html(
    `The curve climbs by one every day in ${joinList(full)} (every recorded day is above 75) and is completely flat in ${joinList(none)}. ` +
    `It reaches ${last.cum}, matching the Task 2 count. Missing days add nothing, so the total counts recorded days only.`);
}

/* ---------- Task 4 ---------- */
function task4(S) {
  const c = makeSvg("#t4-chart", { H: 400, label: "City centre and suburb PM2.5 through 2025" });
  const x = d3.scaleTime().domain(d3.extent(S.rows, d => d.date)).range([0, c.w]);
  const y = d3.scaleLinear().domain([0, d3.max(S.rows, d => Math.max(d.city, d.suburb)) * 1.06]).nice().range([c.h, 0]);
  drawAxes(c, x, y, "PM2.5 (µg/m³)");
  drawGaps(c, x, S);
  drawSegments(c.g, S, x, y, d => d.suburb, { stroke: COLOR.suburb, "stroke-width": 1.5, opacity: .95 });
  drawSegments(c.g, S, x, y, d => d.city, { stroke: COLOR.city, "stroke-width": 1.5, opacity: .95 });
  addHover(c, x, S.rows, [{ val: d => d.city, y, color: COLOR.city }, { val: d => d.suburb, y, color: COLOR.suburb }],
    d => `<b>${fmtDate(d.date)}</b><br>City: ${f1(d.city)}<br>Suburb: ${f1(d.suburb)}<br>Gap: ${f1(d.city - d.suburb)} µg/m³`);
  const mx = S.maxDiff, hi = [...S.months].sort((a, b) => b.gapMean - a.gapMean);
  d3.select("#t4-read").html(
    `The two lines rise and fall together (correlation ${d3.format(".2f")(S.rCitySub)}). The suburb is lower than the city on ${S.subLower} of ${S.n} days. ` +
    `The gap is widest in ${hi[0].name} (city is ${f1(hi[0].gapMean)} µg/m³ higher on average) and nearly closes in ${hi[11].name} (${f1(hi[11].gapMean)}). ` +
    `The biggest single-day gap is ${fmtDate(mx.date)}: city ${f1(mx.city)} against suburb ${f1(mx.suburb)}.`);
}

/* ---------- Task 5 ---------- */
function task5(S) {
  d3.select("#t5-legend").selectAll("span").data(LEVELS).join("span").html(d => `<i class="box" style="background:${d.color};border:1px solid #0002"></i>${d.label}`);
  const c = makeSvg("#t5-chart", { H: 410, label: "Days per pollution level in each month" });
  const x = d3.scaleBand().domain(d3.range(12)).range([0, c.w]).padding(.2);
  const y = d3.scaleLinear().domain([0, 34]).range([c.h, 0]);
  c.g.append("g").attr("class", "grid").call(d3.axisLeft(y).tickValues([0, 5, 10, 15, 20, 25, 30]).tickSize(-c.w).tickFormat(""));
  c.g.append("g").attr("class", "axis").attr("transform", `translate(0,${c.h})`).call(d3.axisBottom(x).tickFormat(i => MONTHS[i]));
  c.g.append("g").attr("class", "axis").call(d3.axisLeft(y).tickValues([0, 5, 10, 15, 20, 25, 30]));
  c.svg.append("text").attr("class", "ylab").attr("transform", "rotate(-90)").attr("x", -(c.m.top + c.h / 2)).attr("y", 16).attr("text-anchor", "middle").text("Days");
  const data = S.months.map(m => ({ mi: m.mi, ...m.lv, total: m.n }));
  const series = d3.stack().keys(LEVELS.map(l => l.key))(data);
  const hatch = addHatch(c.svg);
  const col = d3.scaleOrdinal(LEVELS.map(l => l.key), LEVELS.map(l => l.color));
  // dashed outline marks calendar days with no reading (March)
  S.months.filter(m => m.cal > m.n).forEach(m => {
    c.g.append("rect").attr("x", x(m.mi)).attr("width", x.bandwidth()).attr("y", y(m.cal)).attr("height", y(m.n) - y(m.cal))
      .attr("fill", hatch).attr("stroke", "#8a94a0").attr("stroke-dasharray", "4 3");
  });
  const groups = c.g.selectAll("g.lvl").data(series).join("g").attr("class", "lvl").attr("fill", d => col(d.key));
  groups.selectAll("rect").data(d => d.map(v => ({ v, key: d.key }))).join("rect")
    .attr("x", d => x(d.v.data.mi)).attr("width", x.bandwidth()).attr("y", d => y(d.v[1])).attr("height", d => y(d.v[0]) - y(d.v[1]))
    .attr("stroke", "#fff").attr("stroke-width", .8)
    .on("pointermove", (event, d) => {
      const m = S.months[d.v.data.mi];
      showTip(`<b>${m.long}</b>: ${m.n} recorded of ${m.cal} days<br>` + LEVELS.map(l => `${l.key}: ${m.lv[l.key]}`).join("<br>"), event);
    }).on("pointerleave", hideTip);
  groups.each(function (s) {
    d3.select(this).selectAll("text").data(s.filter(v => v[1] - v[0] >= 1.6).map(v => ({ v, key: s.key }))).join("text")
      .attr("x", d => x(d.v.data.mi) + x.bandwidth() / 2).attr("y", d => y((d.v[0] + d.v[1]) / 2) + 4).attr("text-anchor", "middle")
      .style("font", "600 11px system-ui").attr("fill", d => (d.key === "High" || d.key === "Severe") ? "#fff" : "#2b2b2b")
      .attr("pointer-events", "none").text(d => d.v[1] - d.v[0]);
  });
  c.g.selectAll("text.tot").data(S.months).join("text").attr("class", "tot").attr("x", d => x(d.mi) + x.bandwidth() / 2)
    .attr("y", d => y(d.cal) - 6).attr("text-anchor", "middle").style("font", "600 11.5px system-ui").attr("fill", "#17212b")
    .text(d => d.n === d.cal ? `${d.n}` : `${d.n} of ${d.cal}`);
  const m3 = S.months[2], sev = S.months.filter(m => m.lv.Severe > 0), lowM = [...S.months].sort((a, b) => b.lv.Low - a.lv.Low)[0];
  d3.select("#t5-read").html(
    `Severe days appear in ${joinList(sev.map(m => `${m.name} (${m.lv.Severe})`))}: ${S.sevTotal} in all. ${lowM.long} has the most Low days (${lowM.lv.Low} of ${lowM.n}). ` +
    `Bars differ in height for two reasons. February has ${S.months[1].cal} calendar days, and ${m3.long} shows only ${m3.n} recorded days because ${S.missing} days are missing (the hatched part of its bar). ` +
    `April, June, September and November have 30 days. The number above each bar is its recorded day count.`);
}

/* ---------- Task 6 ---------- */
function task6(S) {
  const W = 860, H = 600, m = { top: 44, right: 130, bottom: 14, left: 76 };
  const c = makeSvg("#t6-chart", { W, H, m, label: "Heatmap of average city PM2.5 by month and weekday" });
  const rowKeys = [...d3.range(12), "gap", "All"], colKeys = [...d3.range(7), "gap", "All"];
  const y = d3.scaleBand().domain(rowKeys).range([0, c.h]).paddingInner(.06);
  const x = d3.scaleBand().domain(colKeys).range([0, c.w]).paddingInner(.06);
  const cells = [];
  S.months.forEach(mo => {
    d3.range(7).forEach(w => { const v = S.heat.get(mo.mi)?.get(w); if (v) cells.push({ r: mo.mi, c: w, v: v.mean, n: v.n }); });
    cells.push({ r: mo.mi, c: "All", v: mo.mean, n: mo.n });
  });
  d3.range(7).forEach(w => cells.push({ r: "All", c: w, v: S.wdMean[w], n: S.rows.filter(r => weekdayIdx(r) === w).length }));
  cells.push({ r: "All", c: "All", v: S.overall, n: S.n });
  const lo = Math.floor(d3.min(cells, d => d.v)), hi = Math.ceil(d3.max(cells, d => d.v));
  const color = d3.scaleSequential(d3.interpolateYlOrRd).domain([lo, hi]);
  const rowName = k => typeof k === "number" ? MONTHS[k] : k === "All" ? "All months" : "";
  const colName = k => typeof k === "number" ? WEEKDAYS[k] : k === "All" ? "All days" : "";
  c.g.append("g").attr("class", "axis").call(d3.axisTop(x).tickSize(0).tickFormat(colName)).select(".domain").remove();
  c.g.append("g").attr("class", "axis").call(d3.axisLeft(y).tickSize(0).tickFormat(rowName)).select(".domain").remove();
  c.g.selectAll("g.axis text").style("font-size", "12px");
  c.g.selectAll("rect.cell").data(cells).join("rect").attr("class", "cell")
    .attr("x", d => x(d.c)).attr("y", d => y(d.r)).attr("width", x.bandwidth()).attr("height", y.bandwidth())
    .attr("rx", 3).attr("fill", d => color(d.v))
    .on("pointermove", (event, d) => showTip(`<b>${rowName(d.r) || ""} · ${colName(d.c)}</b><br>Average: ${f1(d.v)} µg/m³<br>Based on ${d.n} days`, event))
    .on("pointerleave", hideTip);
  c.g.selectAll("text.val").data(cells).join("text").attr("class", "val")
    .attr("x", d => x(d.c) + x.bandwidth() / 2).attr("y", d => y(d.r) + y.bandwidth() / 2 + 4).attr("text-anchor", "middle")
    .style("font", "600 11.5px system-ui").attr("pointer-events", "none")
    .attr("fill", d => d3.lab(color(d.v)).l < 62 ? "#fff" : "#1c1c1c").text(d => f0(d.v));
  // colour legend
  const lid = "grad" + (++uid), defs = c.svg.append("defs");
  const lg = defs.append("linearGradient").attr("id", lid).attr("x1", 0).attr("x2", 0).attr("y1", 1).attr("y2", 0);
  d3.range(0, 1.001, .1).forEach(t => lg.append("stop").attr("offset", t).attr("stop-color", color(lo + t * (hi - lo))));
  const lx = c.w + 34, lh = 220, ly = 10;
  c.g.append("rect").attr("x", lx).attr("y", ly).attr("width", 16).attr("height", lh).attr("fill", `url(#${lid})`).attr("stroke", "#0002");
  c.g.append("g").attr("class", "axis").attr("transform", `translate(${lx + 16},${ly})`)
    .call(d3.axisRight(d3.scaleLinear([lo, hi], [lh, 0])).ticks(5)).select(".domain").remove();
  c.g.append("text").attr("class", "ylab").attr("x", lx - 2).attr("y", ly - 8).text("Average PM2.5 (µg/m³)").style("font-size", "11px");
  const wmin = d3.min(S.wdMean), wmax = d3.max(S.wdMean);
  const wi = S.wdMean.indexOf(wmax), wj = S.wdMean.indexOf(wmin);
  const spikeCells = S.top.map(d => `${MONTHS[d.date.getMonth()]} ${WEEKDAYS[weekdayIdx(d)]} (${f0(S.heat.get(d.date.getMonth()).get(weekdayIdx(d)).mean)})`);
  d3.select("#t6-read").html(
    `Colour changes mostly down the rows (month), hardly across the columns (weekday). Weekday averages run only from ${f1(wmin)} (${WEEKDAYS[wj]}) to ${f1(wmax)} (${WEEKDAYS[wi]}), ` +
    `while monthly averages run from ${f1(S.byMean[11].mean)} (${S.byMean[11].name}) to ${f1(S.byMean[0].mean)} (${S.byMean[0].name}). ` +
    `The few cells that stand out within a row, ${joinList(spikeCells)}, each contain one of the three highest days and rest on only 4–5 days, so one spike moves them.`);
}

/* ---------- Task 7 ---------- */
function task7(S) {
  const c = makeSvg("#t7-chart", { H: 410, label: "Monthly minimum to maximum band with monthly mean line" });
  const x = d3.scaleTime().domain([new Date(2025, 0, 1), new Date(2025, 11, 31)]).range([0, c.w]);
  const y = d3.scaleLinear().domain([0, d3.max(S.months, m => m.max) * 1.06]).nice().range([c.h, 0]);
  drawAxes(c, x, y, "PM2.5 (µg/m³)");
  c.g.append("line").attr("x1", 0).attr("x2", c.w).attr("y1", y(75)).attr("y2", y(75)).attr("stroke", COLOR.target).attr("stroke-dasharray", "7 5").attr("opacity", .6);
  c.g.append("text").attr("class", "ann halo").attr("x", c.w - 4).attr("y", y(75) - 5).attr("text-anchor", "end").style("fill", COLOR.target).text("75 µg/m³");
  c.g.append("path").datum(S.months).attr("fill", "#f3c9b8").attr("fill-opacity", .85)
    .attr("d", d3.area().x(d => x(d.mid)).y0(d => y(d.min)).y1(d => y(d.max)));
  c.g.append("path").datum(S.months).attr("fill", "none").attr("stroke", "#e39a7c").attr("stroke-width", 1)
    .attr("d", d3.line().x(d => x(d.mid)).y(d => y(d.max)));
  c.g.append("path").datum(S.months).attr("fill", "none").attr("stroke", "#e39a7c").attr("stroke-width", 1)
    .attr("d", d3.line().x(d => x(d.mid)).y(d => y(d.min)));
  c.g.append("path").datum(S.months).attr("fill", "none").attr("stroke", "#b8431a").attr("stroke-width", 3)
    .attr("d", d3.line().x(d => x(d.mid)).y(d => y(d.mean)));
  c.g.selectAll("circle.mean").data(S.months).join("circle").attr("class", "mean").attr("cx", d => x(d.mid)).attr("cy", d => y(d.mean)).attr("r", 3.5).attr("fill", "#b8431a");
  const w = S.bySpread[0];
  c.g.append("line").attr("x1", x(w.mid)).attr("x2", x(w.mid)).attr("y1", y(w.min)).attr("y2", y(w.max)).attr("stroke", "#17212b").attr("stroke-width", 1.5);
  c.g.append("text").attr("class", "ann halo").attr("x", x(w.mid) - 8).attr("y", y(w.max) + 12).attr("text-anchor", "end")
    .text(`${w.long}: ${f1(w.min)} to ${f1(w.max)}`);
  c.g.append("text").attr("class", "ann halo").attr("x", x(w.mid) - 8).attr("y", y(w.max) + 26).attr("text-anchor", "end").style("font-weight", 500)
    .text(`spread ${f1(w.range)} µg/m³`);
  const bis = d3.bisector(d => d.mid).center;
  c.g.append("rect").attr("width", c.w).attr("height", c.h).attr("fill", "none").attr("pointer-events", "all")
    .on("pointermove", event => {
      const m = S.months[bis(S.months, x.invert(d3.pointer(event)[0]))];
      showTip(`<b>${m.long}</b> (${m.n} days)<br>Max: ${f1(m.max)} on ${fmtShort(m.maxRow.date)}<br>Mean: ${f1(m.mean)}<br>Min: ${f1(m.min)} on ${fmtShort(m.minRow.date)}<br>Spread: ${f1(m.range)}`, event);
    }).on("pointerleave", hideTip);
  const w2 = S.bySpread[1], narrow = S.bySpread[11];
  d3.select("#t7-read").html(
    `${w.long} has the widest gap: ${f1(w.min)} to ${f1(w.max)}, a spread of ${f1(w.range)} µg/m³ around a mean of ${f1(w.mean)}. ` +
    `${w2.long} comes next (${f1(w2.range)}), driven by one spike day. The narrowest is ${narrow.long} (${f1(narrow.range)}). ` +
    `A single mean per month hides all of this.`);
}

/* ---------- Task 8 ---------- */
function task8(S) {
  const c = makeSvg("#t8-chart", { H: 420, label: "Daily PM2.5 with 7-day moving average and the sensor outage shaded" });
  const x = d3.scaleTime().domain(d3.extent(S.rows, d => d.date)).range([0, c.w]);
  const y = d3.scaleLinear().domain([0, d3.max(S.rows, d => d.city) * 1.06]).nice().range([c.h, 0]);
  drawAxes(c, x, y, "PM2.5 (µg/m³)");
  drawGaps(c, x, S, { label: true });
  drawSegments(c.g, S, x, y, d => d.city, { stroke: COLOR.daily, "stroke-width": 1, opacity: .75 });
  drawSegments(c.g, S, x, y, d => d.ma, { stroke: COLOR.ma, "stroke-width": 3.4 });
  addHover(c, x, S.rows, [{ val: d => d.city, y, color: COLOR.daily }, { val: d => d.ma, y, color: COLOR.ma }],
    d => `<b>${fmtDate(d.date)}</b><br>Daily: ${f1(d.city)}<br>7-day average: ${f1(d.ma)}`);
  const g0 = S.gaps[0];
  c.svg.append("text").attr("x", c.m.left).attr("y", c.H - 6).style("font", "12px system-ui").style("fill", "#566371")
    .text(`Note: ${S.missing} days missing (${fmtShort(g0.start)} to ${fmtShort(g0.end)} ${g0.start.getFullYear()}). The line is broken here and the average restarts after the gap.`);
  const jan = S.months[0], dec = S.months[11], peak = S.rows.reduce((a, b) => b.ma > a.ma ? b : a), trough = S.rows.reduce((a, b) => b.ma < a.ma ? b : a);
  d3.select("#t8-read").html(
    `With the noise averaged out there is no steady rise or fall, only a seasonal cycle: the 7-day average peaks at ${f1(peak.ma)} on ${fmtDate(peak.date)}, bottoms out at ${f1(trough.ma)} on ${fmtDate(trough.date)}, ` +
    `and January (${f1(jan.mean)}) and December (${f1(dec.mean)}) end at nearly the same level. ` +
    `The sensor has no readings for ${S.missing} days, ${fmtShort(g0.start)}–${fmtShort(g0.end)}, during a month that otherwise averages ${f1(S.months[2].mean)} µg/m³.`);
}

/* ---------- Task 9 ---------- */
function task9(S) {
  const W = 960, H = 470, fm = { top: 14, right: 28, left: 58 }, fh = 296, ch = 56, cy0 = 374;
  const fw = W - fm.left - fm.right;
  const svg = d3.select("#t9-chart").append("svg").attr("viewBox", `0 0 ${W} ${H}`).attr("role", "img")
    .attr("aria-label", "Zoomable daily PM2.5 chart with an overview strip for selecting dates");
  const full = d3.extent(S.rows, d => d.date);
  const x = d3.scaleTime().domain(full).range([0, fw]);
  const y = d3.scaleLinear().range([fh, 0]);
  const x2 = d3.scaleTime().domain(full).range([0, fw]);
  const y2 = d3.scaleLinear().domain([0, d3.max(S.rows, d => d.city) * 1.05]).range([ch, 0]);
  const clipId = "clip" + (++uid);
  svg.append("defs").append("clipPath").attr("id", clipId).append("rect").attr("width", fw).attr("height", fh);
  const hatch = addHatch(svg);

  const focus = svg.append("g").attr("transform", `translate(${fm.left},${fm.top})`);
  const ctx = svg.append("g").attr("transform", `translate(${fm.left},${cy0})`);
  svg.append("text").attr("class", "ylab").attr("transform", "rotate(-90)").attr("x", -(fm.top + fh / 2)).attr("y", 16).attr("text-anchor", "middle").text("PM2.5 (µg/m³)");

  const gridG = focus.append("g").attr("class", "grid");
  const xAxisG = focus.append("g").attr("class", "axis").attr("transform", `translate(0,${fh})`);
  const yAxisG = focus.append("g").attr("class", "axis");
  const plot = focus.append("g").attr("clip-path", `url(#${clipId})`);
  const gapG = plot.selectAll("rect").data(S.gaps).join("rect").attr("fill", hatch).attr("height", fh);
  const gapLab = plot.selectAll("text").data(S.gaps).join("text").attr("class", "ann halo").attr("text-anchor", "middle").attr("y", 14).text("No data: sensor offline");
  const placeRefs = refLines({ g: plot, w: fw, h: fh }, y);
  const daily = drawSegments(plot, S, x, y, d => d.city, { stroke: COLOR.daily, "stroke-width": 1.2 });
  const avg = drawSegments(plot, S, x, y, d => d.ma, { stroke: COLOR.ma, "stroke-width": 3 });
  const dotG = plot.append("g");

  // hover (uses the live x and y, so it follows the zoom)
  const bis = d3.bisector(d => d.date).center;
  const hv = focus.append("g").style("display", "none").attr("pointer-events", "none");
  const hvLine = hv.append("line").attr("class", "hover-line").attr("y1", 0).attr("y2", fh);
  const hvDot = hv.append("circle").attr("r", 4.5).attr("fill", "#fff").attr("stroke", COLOR.city).attr("stroke-width", 2);
  focus.append("rect").attr("width", fw).attr("height", fh).attr("fill", "none").attr("pointer-events", "all")
    .on("pointermove", event => {
      const [mx] = d3.pointer(event); const when = x.invert(mx);
      const d = S.rows[bis(S.rows, when)]; hv.style("display", null);
      if (Math.abs(d.date - when) > 1.5 * DAY) { hvLine.attr("x1", mx).attr("x2", mx); hvDot.style("display", "none");
        showTip(`<b>${fmtDate(when)}</b><br>No data: sensor offline`, event); return; }
      hvLine.attr("x1", x(d.date)).attr("x2", x(d.date)); hvDot.style("display", null).attr("cx", x(d.date)).attr("cy", y(d.city));
      showTip(`<b>${fmtDate(d.date)}</b><br>Daily: ${f1(d.city)} µg/m³ (${d.level})<br>7-day average: ${f1(d.ma)}`, event);
    }).on("pointerleave", () => { hv.style("display", "none"); hideTip(); });

  function update(dom) {
    x.domain(dom);
    const vis = S.rows.filter(d => d.date >= dom[0] && d.date <= dom[1]);
    if (vis.length) y.domain([0, d3.max(vis, d => d.city) * 1.1]).nice();
    const span = d3.timeDay.count(dom[0], dom[1]);
    xAxisG.call(d3.axisBottom(x).ticks(span > 200 ? d3.timeMonth.every(1) : span > 75 ? d3.timeWeek.every(2) : 8).tickFormat(span > 200 ? d3.timeFormat("%b") : d3.timeFormat("%-d %b")));
    yAxisG.call(d3.axisLeft(y).ticks(6));
    gridG.call(d3.axisLeft(y).ticks(6).tickSize(-fw).tickFormat(""));
    daily.redraw(); avg.redraw(); placeRefs();
    gapG.attr("x", d => x(d.lastBefore.date)).attr("width", d => x(d.firstAfter.date) - x(d.lastBefore.date));
    gapLab.attr("x", d => (x(d.lastBefore.date) + x(d.firstAfter.date)) / 2);
    dotG.selectAll("circle").data(vis.length <= 60 ? vis : [], d => +d.date).join("circle")
      .attr("r", 3).attr("fill", COLOR.city).attr("cx", d => x(d.date)).attr("cy", d => y(d.city));
    const days = vis.length;
    d3.select("#t9-readout").text(span >= d3.timeDay.count(full[0], full[1]) - 1
      ? `Showing the full year · ${S.n} daily readings`
      : vis.length ? `Showing ${fmtDate(vis[0].date)} to ${fmtDate(vis[days - 1].date)} · ${days} readings in ${d3.timeDay.count(vis[0].date, vis[days - 1].date) + 1} days`
                   : "No readings in the selected range");
  }

  // overview strip + brush
  S.gaps.forEach(gp => ctx.append("rect").attr("x", x2(gp.lastBefore.date)).attr("width", x2(gp.firstAfter.date) - x2(gp.lastBefore.date)).attr("height", ch).attr("fill", hatch));
  const cline = d3.line().x(d => x2(d.date)).y(d => y2(d.city));
  ctx.append("g").attr("fill", "none").attr("stroke", COLOR.city).attr("stroke-width", 1.1)
    .selectAll("path").data(S.segs).join("path").attr("d", s => cline(s));
  ctx.append("line").attr("x1", 0).attr("x2", fw).attr("y1", y2(75)).attr("y2", y2(75)).attr("stroke", COLOR.target).attr("stroke-dasharray", "4 3").attr("opacity", .6);
  ctx.append("g").attr("class", "axis").attr("transform", `translate(0,${ch})`).call(monthAxis(x2));
  const hint = ctx.append("text").attr("x", fw - 6).attr("y", 12).attr("text-anchor", "end").style("font", "11px system-ui").style("fill", "#566371")
    .text("Drag here to choose a period");
  const brush = d3.brushX().extent([[0, 0], [fw, ch]]).on("brush end", event => {
    if (event.selection) { hint.style("opacity", 0); update(event.selection.map(x2.invert)); }
    else { hint.style("opacity", 1); update(full); }
  });
  const brushG = ctx.append("g").attr("class", "brush").call(brush);

  d3.select("#t9-reset").on("click", () => brushG.call(brush.move, null));
  const widest = S.bySpread[0];
  d3.select("#t9-widest").text(`Zoom to the widest-spread month (${widest.long})`)
    .on("click", () => brushG.call(brush.move, [x2(new Date(+widest.start - DAY / 2)), x2(new Date(+widest.next - DAY / 2))]));
  update(full);
}

/* ---------- Questions for the Director ---------- */
function answers(S) {
  const M = S.months, worst = S.byMean[0], second = S.byMean[1], best = S.byMean[11], best2 = S.byMean[10];
  const [t1, t2, t3] = S.top;
  const nb = d => {                                    // neighbouring readings, if recorded on consecutive days
    const i = S.rows.indexOf(d), p = S.rows[i - 1], n = S.rows[i + 1];
    return { prev: p && d3.timeDay.count(p.date, d.date) === 1 ? p.city : null, next: n && d3.timeDay.count(d.date, n.date) === 1 ? n.city : null };
  };
  const n1 = nb(t1), n2 = nb(t2), sevMonths = M.filter(m => m.lv.Severe > 0);
  const lowM = [...M].sort((a, b) => b.lv.Low - a.lv.Low)[0];
  const full = M.filter(m => m.above75 === m.n), none = M.filter(m => m.above75 === 0);
  const gapHi = [...M].sort((a, b) => b.gapMean - a.gapMean), g0 = S.gaps[0];
  const wd = S.wdMean, wmax = d3.max(wd), wmin = d3.min(wd);
  const wkday = d3.mean(wd.slice(0, 5)), wkend = d3.mean(wd.slice(5));
  const wide = S.bySpread[0], wide2 = S.bySpread[1];
  const nov = wide.rows, novSwing = d3.mean(nov.slice(1), (r, i) => Math.abs(r.city - nov[i].city));
  const julM = best, julSwing = d3.mean(julM.rows.slice(1), (r, i) => Math.abs(r.city - julM.rows[i].city));
  const janM = M[0], decM = M[11], febM = M[1];
  const pick = [...M].sort((a, b) => b.lv.Severe - a.lv.Severe).slice(0, 2).sort((a, b) => a.mi - b.mi);
  const oth = S.byMean.filter(m => !pick.includes(m));
  const [p1, p2] = pick, pickSev = p1.lv.Severe + p2.lv.Severe, pickDays = p1.n + p2.n;
  const sd = (d) => `${fmtDate(d.date)} (${f1(d.city)})`;
  const items = [
    ["Seasonality", "Task 5 and Task 7 charts, Task 8 average",
      `<p>${worst.long} is the worst month (mean ${f1(worst.mean)} µg/m³), followed by ${second.long} (${f1(second.mean)}). ${best.long} is the best (${f1(best.mean)}), then ${best2.long} (${f1(best2.mean)}). ` +
      `The worst month is about <b>${f1(worst.mean / best.mean)} times</b> the best. Pollution is high from November to March, falls through spring, sits at its floor in June–August and rebuilds from September. ` +
      `City PM2.5 moves opposite to temperature (correlation ${d3.format(".2f")(S.rCityTemp)}). That is consistent with winter heating, burning and stagnant cold air versus monsoon rain and mixing, but the file alone cannot prove a cause.</p>`],
    ["Anomalies", "Task 2 chart (labelled points)",
      `<p>The two highest days are <b>${sd(t1)}</b> and <b>${sd(t2)}</b>. Both are isolated spikes, not part of the seasonal pattern: ` +
      `${fmtShort(t1.date)} sits between ${n1.prev ?? "n/a"} and ${n1.next ?? "n/a"} and is ${f1(t1.city / M[t1.date.getMonth()].mean)}× its month's mean; ` +
      `${fmtShort(t2.date)} sits between ${n2.prev ?? "n/a"} and ${n2.next ?? "n/a"}, about ${f1(t2.city / M[t2.date.getMonth()].mean)}× a month whose mean is ${f1(M[t2.date.getMonth()].mean)}, and it falls in the warm, low-pollution season. ` +
      `The next highest, ${sd(t3)}, is also a one-day spike. Both suburb readings jumped on the same days (${f1(t1.suburb)} and ${f1(t2.suburb)}), so two sensors agree and a single faulty sensor is unlikely.</p>` +
      `<p>Possible real-world causes (hypotheses to check, not findings): a dust storm or heavy pre-monsoon wind (warm ${t2.temp} °C day), a large fire or waste or crop-residue burning upwind, an industrial accident, a festival fireworks night, or a short stagnant-air episode. Checking wind records, satellite fire maps and news for those dates would narrow it down.</p>`],
    ["Guideline", "Task 2 chips",
      `<p><b>${S.above15}</b> days were above 15 µg/m³ (<b>${pct(S.above15 / S.n)}</b> of the ${S.n} recorded days) and <b>${S.above75}</b> were above 75 µg/m³ (<b>${pct(S.above75 / S.n)}</b>). ` +
      `Only ${S.lowDays.map(d => fmtDate(d.date) + " at " + f1(d.city)).join(", ")} met the WHO guideline. Shares use recorded days, not 365, because ${S.missing} days have no reading.</p>`],
    ["Build-up", "Task 3 area chart",
      `<p>The curve is steepest in ${joinList(full.map(m => m.name))}: every recorded day in those months is above 75, so it gains one day per day. It goes flat in ${joinList(none.map(m => m.name))} (no unhealthy day at all), ` +
      `and the longest flat stretch runs ${fmtShort(S.flat[0].date)} to ${fmtShort(S.flat[S.flat.length - 1].date)} (${S.flat.length} days in a row at or below 75). Over the year it reaches ${S.above75}.</p>`],
    ["Comparison", "Task 4 chart",
      `<p>Yes, the suburb follows the same pattern (correlation ${d3.format(".2f")(S.rCitySub)}) and sits lower: it is below the city on ${S.subLower} of ${S.n} days and averages ${f1(S.subMeanAll)} against ${f1(d3.mean(S.rows, r => r.city))} in the city. ` +
      `The two differ most in winter: the monthly gap is largest in ${gapHi[0].long} (${f1(gapHi[0].gapMean)} µg/m³) and smallest in ${gapHi[11].long} (${f1(gapHi[11].gapMean)}). ` +
      `The biggest single-day gap is ${fmtDate(S.maxDiff.date)} (city ${f1(S.maxDiff.city)}, suburb ${f1(S.maxDiff.suburb)}), which points to a city-centre source that day.</p>`],
    ["Composition", "Task 5 stacked bars",
      `<p>Severe days occur in ${joinList(sevMonths.map(m => `${m.long} (${m.lv.Severe})`))}, ${S.sevTotal} in total. ${lowM.long} has the most Low days: ${lowM.lv.Low} of ${lowM.n}. ` +
      `Months have different lengths for two reasons: February has only ${febM.cal} days, and March shows only ${M[2].n} because ${S.missing} of its days are missing. April, June, September and November have 30 days. ` +
      `When comparing months, use the share of days rather than the raw count, especially for March.</p>`],
    ["Pattern", "Task 6 heatmap",
      `<p>The pattern is mostly by month. Weekday averages differ by only ${f1(wmax - wmin)} µg/m³ (${f1(wmin)} to ${f1(wmax)}), against ${f1(worst.mean - best.mean)} between the best and worst months. ` +
      `There is a small weekend dip (Mon–Fri average ${f1(wkday)}, Sat–Sun ${f1(wkend)}). The bright cells inside single rows are one-off spike days, not a weekday habit. ` +
      `Because the weekly rhythm of traffic and industry barely shows, the main drivers look seasonal and regional (weather, heating, burning, trapped air) rather than commuting, though a modest local traffic or industry share cannot be ruled out.</p>`],
    ["Spread", "Task 7 band chart",
      `<p>${wide.long} has the widest gap: ${f1(wide.min)} on ${fmtShort(wide.minRow.date)} to ${f1(wide.max)} on ${fmtShort(wide.maxRow.date)}, a spread of <b>${f1(wide.range)} µg/m³</b>. ` +
      `${wide2.long} is second (${f1(wide2.range)}). A monthly average hides this because it collapses the whole month into one number: ${wide.long}'s mean of ${f1(wide.mean)} says nothing about a day of ${f1(wide.max)} or a day of ${f1(wide.min)}, ` +
      `and ${wide2.long}'s mean of ${f1(wide2.mean)} gives no hint of its ${f1(wide2.max)} day.</p>`],
    ["Trend and data quality", "Task 8 chart",
      `<p>There is only a seasonal cycle: January averages ${f1(janM.mean)} and December ${f1(decM.mean)}, so the year ends where it started, and the 7-day average just goes down in spring and up again in autumn. One year cannot show a long-term trend; that needs the same months across several years. ` +
      `<b>${S.missing} days</b> are missing (${fmtDate(g0.start)} to ${fmtDate(g0.end)}). An unbroken line over the gap is misleading because it draws a straight line between ${f1(g0.lastBefore.city)} and ${f1(g0.firstAfter.city)} as if readings existed, ` +
      `hides that the sensor was offline, and a moving average across it would blend days that are ${S.missing + 1} days apart. It happened in a high-pollution month, so we may have missed unhealthy days.</p>`],
    ["Zoom", "Task 9 explorer (press 'Zoom to the widest-spread month')",
      `<p>Zoomed to ${wide.long}, you can read each of the ${wide.n} days. The ${fmtShort(wide.maxRow.date)} peak of ${f1(wide.max)} is a one-day event (${nb(wide.maxRow).prev ?? "n/a"} the day before, ${nb(wide.maxRow).next ?? "n/a"} after), ` +
      `every day of the month is above the 75 line (lowest ${f1(wide.min)} on ${fmtShort(wide.minRow.date)}), and readings jump by about ${f0(novSwing)} µg/m³ from one day to the next on average (versus ${f0(julSwing)} in ${julM.long}). ` +
      `The 7-day average hides most of that, and in the full-year view the same month is squeezed into only about ${f0(876 / 365 * wide.cal)} pixels wide, so you could not read the dates or see that the spike stands alone.</p>`],
    ["Chart choice", "All charts compared with the pie chart",
      `<p>A pie of monthly averages cannot tell the Director: <b>(1) what changed and when</b>. Slices show shares of a whole, not direction, so nobody can see that pollution falls from ${f1(febM.mean)} in February to ${f1(best.mean)} in ${best.name} and climbs back, or when each change happens. Averages also do not add up to a meaningful whole. ` +
      `<b>(2) how bad the worst days are and whether the data is complete</b>. It cannot show the ${f1(t1.city)} spike on ${fmtShort(t1.date)}, the ${S.above75} days above 75, the ${S.sevTotal} Severe days, or the ${S.missing}-day outage in March, which a pie would present as a normal month.</p>`],
    ["Recommendation", "Task 5, Task 3, Task 6 and Task 7 together",
      `<p>I would restrict outdoor school activities in <b>${p1.long} and ${p2.long}</b>. Evidence: (a) the Task 5 stacks show these two months have the most Severe days (${p1.lv.Severe} + ${p2.lv.Severe} = ${pickSev} of the year's ${S.sevTotal}), ` +
      `and every one of their ${pickDays} days is High or Severe; (b) the Task 3 curve climbs one step per day through both; (c) the Task 7 band puts even their best days at ${f1(p1.min)} and ${f1(p2.min)} µg/m³, above the 75 target, so there is no clean day to schedule around; ` +
      `(d) the Task 6 heatmap shows no weekday that is safe, so weekend-only measures would not help. They also run back to back across the new year, which makes a simple rule to communicate.</p>` +
      `<p>Caveat: ${oth[0].long} (mean ${f1(oth[0].mean)}, best day ${f1(oth[0].min)}) and ${oth[1].long} (${f1(oth[1].mean)}) are close behind, so the choice is not clear-cut. Check the school calendar first: if schools are on winter break during the chosen weeks, the restriction would protect fewer children and a neighbouring month may be the better use of the two months.</p>`]
  ];
  d3.select("#answers").selectAll("div.qa").data(items).join("div").attr("class", "qa")
    .html((d, i) => `<h3>${i + 1}. ${d[0]}</h3><p class="from">Evidence: ${d[1]}</p>${d[2]}`);
}
