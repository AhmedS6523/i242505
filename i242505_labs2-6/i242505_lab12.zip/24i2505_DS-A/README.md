# FAST NUCES — Data Analysis and Visualization, Lab 12

**Roll number:** 24i2505  
**Section:** DS-A

This folder contains the complete Lab 12 submission using the provided Shopee Orders dataset: Tasks 1–8, original prompts and first-pass outputs, corrected prompts, verification, charts, and explanations.

## Files
- `24i2505_DS-A_Lab12_Report.docx` — report and prompt log.
- `24i2505_DS-A_Lab12.ipynb` — executed verification notebook (24 cells).
- `dataset/Shopee Orders(1).csv` — original dataset, unchanged.
- `figures/` — 13 exported figures.
- `requirements.txt` — required Python packages.

## Run
From this folder:

```bash
python -m pip install -r requirements.txt
jupyter notebook 24i2505_DS-A_Lab12.ipynb
```

Then choose **Kernel > Restart & Run All**. The notebook uses `dataset/` relative to this folder.

## Submit
1. Upload `24i2505_DS-A_Lab12.zip` to Google Classroom.
2. Push this folder to the section GitHub repository at `Week_12/24i2505_DS-A/`.
3. Ensure the report, notebook, source CSV and charts are included in both submission locations.

The currency conversion of 1 USD = 280 PKR is specified by the lab manual.
